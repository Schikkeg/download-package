package org.sample.ecom.lucene;

import java.io.IOException;
import org.apache.jackrabbit.core.id.NodeId;
import org.apache.jackrabbit.core.query.lucene.ExcerptProvider;
import org.apache.jackrabbit.core.query.lucene.SearchIndex;
import org.apache.lucene.search.Query;

public class EmptyExcerptProvider
  implements ExcerptProvider
{

  public EmptyExcerptProvider() {}
  
  public String getExcerpt(NodeId id, int maxFragments, int maxFragmentSize)
    throws IOException
  {
    return "";
  }

  public void init(Query query, SearchIndex index)
    throws IOException
  {
  }
}