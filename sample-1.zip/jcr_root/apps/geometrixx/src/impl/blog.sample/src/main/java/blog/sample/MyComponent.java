package blog.sample;

import org.apache.felix.scr.annotations.Component;
import org.apache.felix.scr.annotations.ConfigurationPolicy;

/**
    * Implements the Sample ConfigurationPolicy REQUIRE
    *
    */
@Component(metatype=true,
        policy= ConfigurationPolicy.REQUIRE)


public class MyComponent{

}