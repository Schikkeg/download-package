
package com.sample.loginredirect.filter;

import javax.servlet.*;
import java.io.IOException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.RequestDispatcher;

public class LoginRedirectFilter
    implements Filter
{
    private final String name;

    public LoginRedirectFilter(String name)
    {
        this.name = name;
    }
    
    public void init(FilterConfig config)
        throws ServletException
    {
        doLog("Init with config [" + config + "]");
    }

    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
        throws IOException, ServletException
    {
    	if ( req instanceof HttpServletRequest && res instanceof HttpServletResponse ) {
            final HttpServletRequest request = (HttpServletRequest)req;
    		final HttpServletResponse response = (HttpServletResponse)res;
    		
    		String pathInfo = request.getPathInfo() ;
    		boolean crxdeAuthenticated = false;
    		boolean crxAuthenticated = false;

    		if(pathInfo != null){
               Cookie[] cookies = request.getCookies();
                if(cookies!=null){
                	for (int i = 0; i < cookies.length; i++) {
      					String name = cookies[i].getName();
      					String value = cookies[i].getValue();

      					if(name!=null && name.equals("login-workspace") && value!=null){
				    		 crxAuthenticated = true;			      				
    	  				}
	      				if(name!=null && name.equals("login-token") && value!=null){
			    			 crxdeAuthenticated = true;			      				
      					}
    				}
                }
                if(pathInfo.startsWith("/crx/explorer/crx_main_files/admin.css")){
						//Do nothing
                }else if ( !pathInfo.startsWith("/crx/explorer/login.jsp") && pathInfo.startsWith("/crx/explorer") &&  !crxAuthenticated ){
					  response.sendRedirect("/crx/explorer/login.jsp");
  					return;
    			}else if( ( pathInfo.startsWith("/crxde") || pathInfo.startsWith("/crx/de") ) &&  !crxdeAuthenticated ){
					RequestDispatcher rd = request.getRequestDispatcher("/libs/granite/core/content/login.html");
  					rd.forward(request, response);
  					return;
    			}
    		
    		}	
	    }
        chain.doFilter(req, res);
    }

    public void destroy()
    {
        doLog("Destroyed filter");
    }

    private void doLog(String message)
    {
        System.out.println("## [" + this.name + "] " + message);
    }
}
