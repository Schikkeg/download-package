
package com.sample.loginredirect.filter;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTracker;
import org.apache.felix.http.api.ExtHttpService;

public final class Activator
    implements BundleActivator
{
    private ServiceTracker tracker;
    private LoginRedirectFilter filter = new LoginRedirectFilter("filter");

    public void start(BundleContext context)
        throws Exception
    {
        this.tracker = new ServiceTracker(context, ExtHttpService.class.getName(), null)
        {
            @Override
            public Object addingService(ServiceReference ref)
            {
                Object service =  super.addingService(ref);
                serviceAdded((ExtHttpService)service);
                return service;
            }

            @Override
            public void removedService(ServiceReference ref, Object service)
            {
                serviceRemoved((ExtHttpService)service);
                super.removedService(ref, service);
            }
        };

        this.tracker.open();
    }

    public void stop(BundleContext context)
        throws Exception
    {
        this.tracker.close();
    }

    private void serviceAdded(ExtHttpService service)
    {
        try {
            service.registerFilter(this.filter, "/crx/.*", null, 100, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void serviceRemoved(ExtHttpService service)
    {
        service.unregisterFilter(this.filter);
    }
}

